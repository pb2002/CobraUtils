# PyUtils

## About

PyUtils is a Python module that provides various utilities that are commonly used when programming in Python.
These include easy command line styling, secure input queries, extended math implementations and many more.

## How to use

Download the repository and 
## Version Log

### Alpha 1.0-1a (June 8th, 2019)

This is the first version of PyUtils!

